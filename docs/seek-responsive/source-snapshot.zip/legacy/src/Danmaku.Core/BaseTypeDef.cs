﻿// Copyright (c) Richasy. All rights reserved.
// This file is kept for backward compatibility.
// All types have been moved to separate files in Enums/ and Models/ folders.

// Re-export types for backward compatibility
global using Richasy.Danmaku.Enums;
global using Richasy.Danmaku.Models;

namespace Richasy.Danmaku;

// All types have been moved to:
// - Enums/DanmakuMode.cs
// - Enums/DanmakuPool.cs
// - Enums/DanmakuFontSize.cs
// - Enums/DanmakuAlignmentMode.cs
// - Models/DanmakuItem.cs
// - Models/DanmakuDefaultLayerDef.cs

