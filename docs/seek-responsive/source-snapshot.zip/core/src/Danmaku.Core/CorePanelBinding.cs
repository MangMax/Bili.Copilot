using System.Runtime.InteropServices;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml.Controls;
using WinRT;

namespace Richasy.Danmaku;

internal sealed class CorePanelBinding : ICoreSurfaceBinding
{
    private readonly SwapChainPanel panel;
    private readonly DispatcherQueue queue;
    internal CorePanelBinding(SwapChainPanel panel)
    {
        this.panel = panel; queue = panel.DispatcherQueue;
        if (!queue.HasThreadAccess) throw new InvalidOperationException("Capture panel binding on UI");
    }
    public bool TryEnqueue(Action callback) => queue.TryEnqueue(() => callback());
    public unsafe void Bind(nint surface)
    {
        if (!queue.HasThreadAccess) throw new InvalidOperationException("Bind on UI only");
        nint pointer = panel.As<IWinRTObject>().NativeObject.ThisPtr;
        Guid iid = new("63aad0b8-7c24-40ff-85a8-640d944cc325");
        Marshal.ThrowExceptionForHR(Marshal.QueryInterface(pointer, in iid, out nint native));
        try
        {
            var table = *(nint**)native;
            Marshal.ThrowExceptionForHR(((delegate* unmanaged[Stdcall]<nint, nint, int>)table[3])(native, surface));
        }
        finally { Marshal.Release(native); }
    }
}
