// Isolated OX resource consumer. The public renderer is deliberately not wired here.
using System.Collections.Concurrent;

namespace Richasy.Danmaku;

internal readonly record struct CoreResourceStamp(Guid Instance, long Scene, long Intent, long Epoch);
internal enum CoreResourceOutcome { Applied, Superseded, Closed, Faulted }

internal readonly record struct CoreSurfaceSize(float Width, float Height, float Scale)
{
    internal bool Positive => float.IsFinite(Width) && float.IsFinite(Height) && float.IsFinite(Scale)
        && Width > 0 && Height > 0 && Scale > 0;
}

internal interface ICoreOwnedSurface : IDisposable
{
    nint Pointer { get; }
    void AcquireLease();
    void ReleaseLease();
    void Initialize(CoreSurfaceSize size);
    void Resize(CoreSurfaceSize size);
    void Prepare();
    void Present();
}

// Binding captures ONE panel for the whole instance. It never resolves a current child.
internal interface ICoreSurfaceBinding
{
    bool TryEnqueue(Action callback);
    void Bind(nint surface);
}

internal interface ICoreSceneSurface { void ChangeScene(long scene); }

internal sealed class CoreResourceHost
{
    // Process root, not a managed reference cycle. One unresolved allocation per host.
    private static readonly ConcurrentDictionary<CoreResourceHost, byte> Hosts = new();
    private readonly object gate = new();
    private CoreResourceOwner? active;
    private bool faulted;
    internal int RootCount { get { lock (gate) return active == null ? 0 : 1; } }
    internal bool Faulted { get { lock (gate) return faulted; } }
    internal void Register(CoreResourceOwner owner)
    {
        lock (gate)
        {
            if (faulted || active != null)
            {
                faulted = true;
                throw new InvalidOperationException("Host resource admission is closed");
            }
            active = owner;
            Hosts.TryAdd(this, 0);
        }
    }
    internal void Fault() { lock (gate) faulted = true; }
    internal void Retire(CoreResourceOwner owner)
    {
        lock (gate)
        {
            if (ReferenceEquals(active, owner)) active = null;
            // A fault latch lives for the host lifetime, including after a late ack.
            if (!faulted) Hosts.TryRemove(this, out _);
        }
    }
}

internal sealed class CoreResourceOwner
{
    private readonly CoreResourceHost host;
    private readonly ICoreSurfaceBinding binding;
    private readonly Func<ICoreOwnedSurface> factory;
    private readonly object admission = new();
    private readonly AutoResetEvent wake = new(false);
    private readonly TaskCompletionSource retirement = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private CoreSurfaceSize size;
    private bool closed, exited;
    private readonly ConcurrentQueue<Action> acknowledgements = new();
    private volatile bool attachSent;
    private bool attached, detachSent;
    private volatile bool leaseReturned;
    private bool hasLease;
    // Worker-only ownership, reachable through Hosts -> host.active even after Run exits.
    // Keep partial/unknown releases rooted; only confirmed disposal relinquishes ownership.
    private ICoreOwnedSurface? surface;
    private bool uiAttempted, uiDetached; // Only accessed inside serialized UI callbacks.
    private readonly Guid instance = Guid.NewGuid();
    private long scene, intent, epoch, sizeRevision, appliedSizeRevision;
    private readonly Queue<(CoreResourceStamp stamp, TaskCompletionSource<CoreResourceOutcome> receipt, Action<ICoreOwnedSurface>? operation)> frames = new();
    private long appliedScene = -1;
    private readonly TaskCompletionSource ready = new(TaskCreationOptions.RunContinuationsAsynchronously);
    internal Task Ready => ready.Task;
    internal Task Retirement => retirement.Task;
    internal Exception? Error { get; private set; }
    internal CoreResourceStamp Capture() { lock (admission) return new(instance, scene, intent, epoch); }
    private CoreResourceOutcome? Invalid(CoreResourceStamp stamp) =>
        Error != null ? CoreResourceOutcome.Faulted : closed ? CoreResourceOutcome.Closed :
        stamp.Instance != instance || stamp.Scene != scene || stamp.Intent != intent || stamp.Epoch != epoch
        || epoch == 0 || sizeRevision != appliedSizeRevision ? CoreResourceOutcome.Superseded : null;
    internal Task<CoreResourceOutcome> SubmitAsync(CoreResourceStamp stamp) => EnqueueAsync(stamp, null);
    internal Task<CoreResourceOutcome> ExecuteAsync(CoreResourceStamp stamp, Action<ICoreOwnedSurface> operation)
        => EnqueueAsync(stamp, operation ?? throw new ArgumentNullException(nameof(operation)));
    private Task<CoreResourceOutcome> EnqueueAsync(CoreResourceStamp stamp, Action<ICoreOwnedSurface>? operation)
    {
        lock (admission)
        {
            if (Invalid(stamp) is { } invalid) return Task.FromResult(invalid);
            var receipt = new TaskCompletionSource<CoreResourceOutcome>(TaskCreationOptions.RunContinuationsAsynchronously);
            frames.Enqueue((stamp, receipt, operation)); wake.Set(); return receipt.Task;
        }
    }
    // Same worker, lease and fault domain as every RX1 operation. A scheduler
    // receipt is only input: validate again around real preparation and Present.
    internal async Task<CoreResourceOutcome> RenderAsync(CoreResourceStamp stamp,
        Func<CoreResourceOutcome?> current, Action<ICoreOwnedSurface> prepare)
    {
        CoreResourceOutcome? rejected = null;
        CoreResourceOutcome? InvalidExecution()
        {
            lock (admission) if (Invalid(stamp) is { } invalid) return invalid;
            return current(); // Pure QX query; no native work under either gate.
        }
        if (InvalidExecution() is { } early) return early;
        var result = await ExecuteAsync(stamp, target =>
        {
            if ((rejected = InvalidExecution()).HasValue) return;
            prepare(target);
            if ((rejected = InvalidExecution()).HasValue) return;
            target.Prepare();
            if ((rejected = InvalidExecution()).HasValue) return;
            // Final execution admission. A later control may let this CPU call
            // finish, but its completion never overwrites that control.
            target.Present();
            rejected = InvalidExecution();
        }).ConfigureAwait(false);
        return result == CoreResourceOutcome.Applied ? rejected ?? result : result;
    }

    internal void PublishScene(long revision) { lock (admission) { if (!closed && revision > scene) { scene = revision; wake.Set(); } } }
    internal void PublishIntent(long revision) { lock (admission) { if (!closed && revision > intent) { intent = revision; wake.Set(); } } }
    internal void RetryExactDetach() { if (Closed && attachSent) Detach(); }
    internal void ReportUnconfirmed(Exception error) => Fault(error);

    internal CoreResourceOwner(CoreResourceHost host, ICoreSurfaceBinding binding, Func<ICoreOwnedSurface> factory, Task? predecessor = null)
    {
        this.host = host; this.binding = binding; this.factory = factory;
        if (predecessor == null) Start();
        else _ = StartAfterAsync(predecessor);
    }
    private async Task StartAfterAsync(Task predecessor)
    {
        try { await predecessor.ConfigureAwait(false); Start(); }
        catch (Exception error) { Fault(error); }
    }
    private void Start()
    {
        host.Register(this);
        new Thread(Run) { IsBackground = true, Name = "Core resource owner" }.Start();
    }
    internal void Resize(float width, float height, float scale)
    {
        lock (admission) { if (closed) return; size = new(width, height, scale); sizeRevision++; wake.Set(); }
    }
    internal void Close()
    {
        lock (admission) { closed = true; ready.TrySetResult(); if (exited) return; wake.Set(); }
        // Posting exact UI detach must not wait for the native worker to return.
        if (attachSent && !leaseReturned) { try { Detach(); } catch (Exception error) { Fault(error); } }
    }
    private bool Closed { get { lock (admission) return closed; } }
    private void Ack(Action action)
    {
        lock (admission)
        {
            if (exited) return;
            acknowledgements.Enqueue(action); wake.Set();
        }
    }
    private void Attach(ICoreOwnedSurface surface)
    {
        surface.AcquireLease(); hasLease = true;
        attachSent = true;
        nint exactPointer = surface.Pointer;
        int invoked = 0;
        if (!binding.TryEnqueue(() =>
        {
            if (Interlocked.Exchange(ref invoked, 1) != 0) return;
            if (Closed) { Ack(() => leaseReturned = true); return; }
            try { uiAttempted = true; binding.Bind(exactPointer); Ack(() => attached = true); }
            catch (Exception error)
            {
                Fault(error);
                Ack(() => { attached = true; detachSent = true; });
                // Binding may have succeeded before throwing. Never consult 'attached'.
                try { binding.Bind(0); uiDetached = true; Ack(() => leaseReturned = true); }
                catch (Exception detachError) { Fault(detachError); }
            }
        })) leaseReturned = true;
    }
    private void Detach()
    {
        detachSent = true;
        int invoked = 0;
        if (!binding.TryEnqueue(() =>
        {
            if (Interlocked.Exchange(ref invoked, 1) != 0) return;
            if (!uiAttempted || uiDetached) return;
            try { binding.Bind(0); uiDetached = true; Ack(() => leaseReturned = true); }
            catch (Exception error) { Fault(error); }
        })) Ack(() => { if (!leaseReturned) Fault(new InvalidOperationException("UI detach enqueue rejected")); });
    }
    private void Fault(Exception error)
    {
        host.Fault();
        lock (admission) { Error ??= error; closed = true; ready.TrySetResult(); if (!exited) wake.Set(); }
    }
    private void Run()
    {
        try
        {
            while (true)
            {
                CoreSurfaceSize requested; long requestedRevision;
                while (acknowledgements.TryDequeue(out var ack)) ack();
                lock (admission) { requested = size; requestedRevision = sizeRevision; }
                if (Closed)
                {
                    lock (admission) while (frames.TryDequeue(out var pending)) pending.receipt.TrySetResult(Error != null ? CoreResourceOutcome.Faulted : CoreResourceOutcome.Closed);
                    if (!attachSent || leaseReturned) break;
                    if (attached && !detachSent) Detach();
                    wake.WaitOne(); continue;
                }
                if (surface == null && requested.Positive)
                {
                    try
                    {
                        surface = factory();
                        surface.Initialize(requested);
                        lock (admission) { epoch++; appliedSizeRevision = requestedRevision; }
                        if (!Closed) Attach(surface);
                        ready.TrySetResult();
                    }
                    catch (Exception error) { Fault(error); }
                }
                else if (surface != null && requested.Positive && requestedRevision != appliedSizeRevision)
                {
                    try { surface.Resize(requested); lock (admission) { epoch++; appliedSizeRevision = requestedRevision; } }
                    catch (Exception error) { Fault(error); }
                }
                while (surface != null)
                {
                    (CoreResourceStamp stamp, TaskCompletionSource<CoreResourceOutcome> receipt, Action<ICoreOwnedSurface>? operation) frame;
                    lock (admission)
                    {
                        if (!frames.TryDequeue(out frame)) break;
                        if (Invalid(frame.stamp) is { } invalid) { frame.receipt.TrySetResult(invalid); continue; }
                    }
                    try
                    {
                        if (appliedScene != frame.stamp.Scene)
                        {
                            if (surface is ICoreSceneSurface scenes) scenes.ChangeScene(frame.stamp.Scene);
                            appliedScene = frame.stamp.Scene;
                        }
                        lock (admission)
                        {
                            if (Invalid(frame.stamp) is { } invalid) { frame.receipt.TrySetResult(invalid); continue; }
                        }
                        if (frame.operation != null)
                        {
                            frame.operation(surface);
                            lock (admission) frame.receipt.TrySetResult(Invalid(frame.stamp) ?? CoreResourceOutcome.Applied);
                            continue;
                        }
                        surface.Prepare();
                        lock (admission)
                        {
                            if (Invalid(frame.stamp) is { } invalid) { frame.receipt.TrySetResult(invalid); continue; }
                        }
                        // This is the execution admission point. Native work never holds admission.
                        // Close/Pause after this point may allow this already-started CPU call to finish.
                        lock (admission)
                        {
                            if (Invalid(frame.stamp) is { } invalid) { frame.receipt.TrySetResult(invalid); continue; }
                        }
                        surface.Present();
                        lock (admission) frame.receipt.TrySetResult(Invalid(frame.stamp) ?? CoreResourceOutcome.Applied);
                    }
                    catch (Exception error) { Fault(error); frame.receipt.TrySetResult(CoreResourceOutcome.Faulted); }
                }
                wake.WaitOne();
            }
            if (hasLease) { surface!.ReleaseLease(); hasLease = false; }
            surface?.Dispose();
            surface = null;
            host.Retire(this);
            lock (admission) { exited = true; wake.Dispose(); }
            retirement.TrySetResult();
        }
        catch (Exception error)
        {
            // Disposal failure is not retirement. Keep the host root; never retry release.
            Fault(error);
        }
    }
}
