namespace Richasy.Danmaku;

internal sealed partial class DanmakuDirectXRender
{
    private readonly int _ownerThread;
    private bool _ownedDisposed;
    private bool _rebuilding;
    private uint _rebuildOrdinal;

    private uint _rebuildTargetMs;
    private TimeSpan _rebuildTotal;

    internal void BeginRebuildOwned(uint target, TimeSpan total)
    {
        VerifyRenderOwner();
        Clear();
        _rebuilding = true;
        _rebuildOrdinal = 0;
        _rebuildTargetMs = target;
        _rebuildTotal = total;
    }
    internal void AdvanceRebuildOwned(TimeSpan step, TimeSpan total)
    {
        VerifyRenderOwner();
        // Synthetic media time only; never publish Resume or advance the playback clock.
        for (uint layer = 0; layer < _renderLayerList.Length; layer++)
            UpdateLayerDanmaku(layer, (float)step.TotalMilliseconds, total);
    }
    internal void EndRebuildOwned() { VerifyRenderOwner(); _rebuilding = false; }

    // Same preparation, update and drawing code, using OX's context and worker.
    // No UI reference, GameLoopThread or CompositionTarget subscription here.
    internal DanmakuDirectXRender(DirectXResourceManager resources, CoreSurfaceSize size)
    {
        _ownerThread = Environment.CurrentManagedThreadId;
        _resourceManager = resources;
        _configState = DanmakuConfigurationState.FromConfiguration(DanmakuConfiguration.CreateDefault());
        _renderLayerList = new RenderLayer[DanmakuDefaultLayerDef.DefaultLayerCount];
        _renderSnapshots = new DanmakuDirectXRenderItem[_renderLayerList.Length][];
        for (uint i = 0; i < _renderLayerList.Length; i++)
        {
            _renderLayerList[i] = new RenderLayer(i, i == DanmakuDefaultLayerDef.AdvancedLayerId || i == DanmakuDefaultLayerDef.SubtitleLayerId);
            _renderSnapshots[i] = new DanmakuDirectXRenderItem[128];
        }
        ResizeOwned(size);
    }
    private void VerifyRenderOwner()
    {
        if (_ownerThread == 0) return; // Legacy facade remains gated by IX.
        if (_ownerThread != Environment.CurrentManagedThreadId)
            throw new InvalidOperationException("Render resource accessed outside OX owner");
        ObjectDisposedException.ThrowIf(_ownedDisposed, this);
    }
    internal void ResizeOwned(CoreSurfaceSize size)
    {
        VerifyRenderOwner(); Clear();
        _resourceManager.SetOwnedSize(size);
        _scale = size.Scale; _dpi = 96 * size.Scale;
        CanvasWidth = size.Width * size.Scale; CanvasHeight = size.Height * size.Scale;
        foreach (var layer in _renderLayerList)
            layer.UpdateYSlotManagerLength((uint)CanvasHeight, _configState.RollingAreaRatio);
    }
    internal void SetPlaybackOwned(bool playing)
    {
        VerifyRenderOwner(); _isPaused = !playing;
    }
    internal void DrawOwned(TimeSpan elapsed, TimeSpan total)
    {
        VerifyRenderOwner();
        UpdateDanmaku(elapsed, total);
        RenderDanmaku(sessionAlreadyOpen: true);
    }
    private void DisposeOwned()
    {
        if (_ownedDisposed) return;
        VerifyRenderOwner(); Clear();
        _cachedOutlineBrush?.Dispose(); _cachedOutlineBrush = null;
        _debugRenderer?.Dispose(); _debugRenderer = null;
        _resourceManager.DisposeOwned();
        _ownedDisposed = true;
    }
}
