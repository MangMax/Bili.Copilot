
namespace Richasy.Danmaku;

internal sealed partial class DanmakuScheduler : IDisposable
{
    private static long _nextInstance;
    private readonly long _instance = Interlocked.Increment(ref _nextInstance);
    private readonly object _admission = new();
    private readonly object _collection = new();
    private readonly Queue<SchedulerWork> _updateTimeQueue = new();
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2213", Justification = "The worker finally disposes the wake after its last Wait; Dispose only closes admission.")]
    private readonly AutoResetEvent _updateEvent = new(false);
    private readonly TaskCompletionSource<bool> _completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private readonly Action<SchedulerSelection> _prepare;
    private readonly Action<long, bool> _applyIntent;
    private List<DanmakuItem> _danmakuList = new();
    private readonly Thread _updateThread;
    private long _scene;
    private long _generation;
    private long _intentRevision;
    private long _intentApplied;
    private bool _playing;
    private bool _stopped;
    private bool _isClosing;
    private Exception _fault;
    private int _pending;
    private int _lastIndex;
    private uint _lastTimeMs;
    private volatile bool _isTopEnabled = true;
    private volatile bool _isBottomEnabled = true;
    private volatile bool _isRollingEnabled = true;

    public event Action<uint, DanmakuItem> DanmakuRendered;
    public event Action PauseRequested;
    public event Action ResumeRequested;
    public event Action StopRequested;

    public DanmakuScheduler() : this(null) { }
    internal DanmakuScheduler(Action<SchedulerSelection> prepare, Action<long, bool> applyIntent = null)
    {
        _prepare = prepare;
        _applyIntent = applyIntent;
        _updateThread = new Thread(UpdaterWorker) { IsBackground = true, Name = "DanmakuScheduler" };
        _updateThread.Start();
    }
    internal Task Completion => _completion.Task;

    // Production query, independent of the fixture's diagnostic State. Callers
    // must revalidate at execution; this value is not a native-use lease.
    internal SchedulerCurrent ReadCurrent()
    {
        lock (_admission)
            return new(_instance, _generation, _scene, _intentRevision, _playing,
                _stopped, _pending != 0, _isClosing, _fault);
    }
    internal SchedulerOutcome? ValidateSelection(SchedulerSelection selection)
    {
        lock (_admission)
        {
            var work = selection.Work;
            return _isClosing ? SchedulerOutcome.Closed : _fault != null ? SchedulerOutcome.Faulted
                : work.Instance != _instance || work.AdmissionScene != _generation || work.Scene != _scene
                  || _pending != 0 || !ReferenceEquals(work.Selection, selection)
                  || !work.Completion.Task.IsCompletedSuccessfully
                ? SchedulerOutcome.Superseded : null;
        }
    }


    public void SetDanmakuEnabledType(bool? isRollingEnabled, bool? isTopEnabled, bool? isBottomEnabled)
    {
        if (isRollingEnabled.HasValue) _isRollingEnabled = isRollingEnabled.Value;
        if (isTopEnabled.HasValue) _isTopEnabled = isTopEnabled.Value;
        if (isBottomEnabled.HasValue) _isBottomEnabled = isBottomEnabled.Value;
    }

    private SchedulerOutcome? Invalid(SchedulerWork work)
        => _isClosing ? SchedulerOutcome.Closed : _fault != null ? SchedulerOutcome.Faulted
        : work.AdmissionScene != _generation ? SchedulerOutcome.Superseded : null;

    internal SchedulerWork Enqueue(uint target, bool seek)
    {
        lock (_admission)
        {
            if (!_isClosing && _fault == null && seek) { _scene++; _generation++; }
            var work = new SchedulerWork(_instance, _generation, _scene, target, seek);
            var invalid = Invalid(work);
            if (invalid.HasValue) work.Completion.TrySetResult(invalid.Value);
            else
            {
                _updateTimeQueue.Enqueue(work);
                _updateEvent.Set();
            }
            return work;
        }
    }
    public void UpdateTime(uint currentMs) => Enqueue(currentMs, false);
    public void Seek(uint targetMs) => Enqueue(targetMs, true);
    public void Restart() { Resume(); Seek(0); }

    private long Intent(bool playing, Action callback)
    {
        long revision;
        lock (_admission)
        {
            if (_isClosing || _fault != null) return _intentRevision;
            revision = ++_intentRevision;
            _playing = playing;
            if (playing) _stopped = false;
            _updateEvent.Set();
        }
        try { callback?.Invoke(); }
        catch (Exception ex)
        {
            // A later reentrant control/Close wins over this failed callback.
            lock (_admission) if (!_isClosing && revision == _intentRevision) Fault(ex);
            throw;
        }
        return revision;
    }
    internal long PauseTracked() => Intent(false, PauseRequested);
    internal long ResumeTracked() => Intent(true, ResumeRequested);
    public void Pause() => Intent(false, PauseRequested);
    public void Resume() => Intent(true, ResumeRequested);

    public void Stop() => StopTracked();
    internal (long Scene, long Intent) StopTracked()
    {
        long scene;
        lock (_admission)
        {
            if (_isClosing || _fault != null) return (_scene, _intentRevision);
            scene = ++_scene;
            _generation++;
            _stopped = true;
            Drain(SchedulerOutcome.Superseded);
        }
        try
        {
            long intent = PauseTracked();
            StopRequested?.Invoke();
            return (scene, intent);
        }
        catch (Exception ex)
        {
            lock (_admission) if (!_isClosing && _scene == scene) Fault(ex);
            throw;
        }
    }

    private long BeginCollection()
    {
        lock (_admission)
        {
            if (_isClosing || _fault != null) return -1;
            _pending++;
            _stopped = true;
            _generation++;
            return ++_scene;
        }
    }
    private void EndCollection(long scene, Exception? error)
    {
        lock (_admission)
        {
            _pending--;
            if (!_isClosing && error != null && scene == _scene) Fault(error);
            // Do not resurrect the outer scene or intent after a reentrant call.
            if (!_isClosing && _fault == null) _updateEvent.Set();
        }
    }
    public void Clear() => Replace(null, false);
    public void SetDanmakuList(List<DanmakuItem> danmakuList) => Replace(danmakuList, true);
    internal long ClearTracked() => Replace(null, false);
    internal long SetTracked(List<DanmakuItem> list) => Replace(list, true);
    private long Replace(List<DanmakuItem> list, bool replace)
    {
        long scene = BeginCollection();
        if (scene < 0) return scene;
        Exception? error = null;
        try
        {
            lock (_collection) _danmakuList.Clear();
            StopRequested?.Invoke();
            // Collection assignment retains the original outer-Set-wins rule,
            // even when its scene was superseded in the callback.
            if (replace)
            {
                lock (_collection) _danmakuList = list ?? new List<DanmakuItem>();
                lock (_admission) if (!_isClosing && scene == _scene) _stopped = false;
            }
        }
        catch (Exception ex) { error = ex; throw; }
        finally { EndCollection(scene, error); }
        return scene;
    }
    public List<DanmakuItem> GetDanmakuList()
    {
        lock (_collection) return _danmakuList.ToList();
    }
    public void AddDanmakuList(List<DanmakuItem> danmakuList)
    {
        lock (_admission) if (_isClosing || _fault != null) return;
        lock (_collection)
        {
            var items = danmakuList.Where(p => !_danmakuList.Any(v => v.Id == p.Id));
            _danmakuList.AddRange(items);
        }
    }

    public void Dispose()
    {
        lock (_admission)
        {
            if (_isClosing) return;
            _isClosing = true;
            _scene++;
            _generation++;
            Drain(SchedulerOutcome.Closed);
            if (!_completion.Task.IsCompleted) _updateEvent.Set();
        }
    }
    private void Drain(SchedulerOutcome outcome)
    {
        while (_updateTimeQueue.Count > 0) _updateTimeQueue.Dequeue().Completion.TrySetResult(outcome);
    }
    private void Fault(Exception error)
    {
        _fault ??= error;
        Drain(SchedulerOutcome.Faulted);
        if (!_completion.Task.IsCompleted) _updateEvent.Set();
    }

    private bool Current(SchedulerWork work)
    {
        lock (_admission) return !Invalid(work).HasValue && _pending == 0;
    }
    private void ApplyIntent()
    {
        while (true)
        {
            long revision;
            bool playing;
            lock (_admission)
            {
                if (_isClosing || _fault != null || _intentApplied == _intentRevision) return;
                revision = _intentRevision;
                playing = _playing;
            }
            _applyIntent?.Invoke(revision, playing);
            lock (_admission)
            {
                if (_isClosing || _fault != null) return;
                if (revision == _intentRevision) { _intentApplied = revision; return; }
            }
        }
    }
    private SchedulerSelection Select(SchedulerWork work)
    {
        int index;
        lock (_admission) index = work.Seek ? 0 : _lastIndex;
        var selected = new List<DanmakuItem>();
        while (Current(work))
        {
            DanmakuItem item;
            lock (_collection)
            {
                // Recheck after acquiring the collection lock. No callback or
                // whole-list scan holds this lock; Pause/Close never acquire it.
                if (!Current(work) || index >= _danmakuList.Count) break;
                item = _danmakuList[index];
            }
            if (item.StartMs > work.Target) break;
            if (work.Seek)
            {
                // Reconstruct recorded entries independently of the live-send skip marker.
                // Ordinary progress retains its original one-shot alias semantics.
                if (item.Mode switch { DanmakuMode.Top => _isTopEnabled, DanmakuMode.Bottom => _isBottomEnabled, _ => _isRollingEnabled }) selected.Add(item);
            }
            else if (item.IsRealtime) item.IsRealtime = false;
            else if (item.Mode switch { DanmakuMode.Top => _isTopEnabled, DanmakuMode.Bottom => _isBottomEnabled, _ => _isRollingEnabled }) selected.Add(item);
            index++;
        }
        return new SchedulerSelection(work, selected, index);
    }
    private void UpdaterWorker()
    {
        SchedulerWork? active = null;
        try
        {
            while (true)
            {
                _updateEvent.WaitOne();
                while (true)
                {
                    ApplyIntent();
                    lock (_admission)
                    {
                        if (_isClosing || _fault != null) return;
                        if (_pending != 0 || _updateTimeQueue.Count == 0) break;
                        active = _updateTimeQueue.Dequeue();
                        if (Invalid(active) == null && !active.Seek) active.Scene = _scene;
                        if (Invalid(active) == null && !active.Seek &&
                            (active.Target < _lastTimeMs || active.Target - _lastTimeMs > 5000))
                        {
                            // Implicit seeks are determined in progress order,
                            // never by a later queued timestamp at admission.
                            // Ordinary progress keeps its admission generation;
                            // only explicit invalidation replaces that lineage.
                            active.Scene = ++_scene;
                            active.Seek = true;
                        }
                    }
                    Dequeued(active);
                    var selection = Select(active);
                    Selected(selection);
                    bool prepare;
                    lock (_admission) prepare = active.Seek || !_stopped;
                    if (Current(active) && prepare)
                    {
                        if (_prepare != null) _prepare(selection);
                        else foreach (var item in selection.Items)
                        {
                            if (!Current(active)) break;
                            DanmakuRendered?.Invoke(GetLayerId(item.Mode), item);
                        }
                    }
                    Submitting(selection);
                    ApplyIntent();
                    lock (_admission)
                    {
                        var invalid = Invalid(active);
                        if (invalid == null && _pending != 0) invalid = SchedulerOutcome.Superseded;
                        if (invalid == null)
                        {
                            _lastIndex = selection.Cursor;
                            _lastTimeMs = active.Target;
                            if (active.Seek) _stopped = false;
                            active.Selection = selection;
                        }
                        active.Completion.TrySetResult(invalid ?? SchedulerOutcome.Applied);
                    }
                    active = null;
                }
            }
        }
        catch (Exception ex)
        {
            lock (_admission)
            {
                active?.Completion.TrySetResult(_isClosing ? SchedulerOutcome.Closed : SchedulerOutcome.Faulted);
                Fault(ex);
            }
        }
        finally
        {
            lock (_admission)
            {
                // This worker is the final waiter. Every producer checks closed
                // or faulted under the same gate before signalling.
                active?.Completion.TrySetResult(_isClosing ? SchedulerOutcome.Closed : SchedulerOutcome.Faulted);
                Drain(_isClosing ? SchedulerOutcome.Closed : SchedulerOutcome.Faulted);
                _updateEvent.Dispose();
                _completion.TrySetResult(true);
            }
        }
    }
    // Erased from the normal build. Definitions belong only to the separately
    // compiled fixture; no diagnostic storage exists in the candidate assembly.
    partial void Dequeued(SchedulerWork work);
    partial void Selected(SchedulerSelection selection);
    partial void Submitting(SchedulerSelection selection);

    public void AddRealtimeDanmaku(DanmakuItem item, bool insertToList)
    {
        lock (_admission) if (_isClosing || _fault != null) return;
        item.AllowDensityControl = false;
        item.IsRealtime = true;

        // 获取图层 ID
        uint layerId = GetLayerId(item.Mode);
        DanmakuRendered?.Invoke(layerId, item);

        if (insertToList)
        {
            lock (_collection)
            {
                bool added = false;
                for (int i = 0; i < _danmakuList.Count; i++)
                {
                    if (_danmakuList[i].StartMs > item.StartMs)
                    {
                        _danmakuList.Insert(i, item);
                        added = true;
                        break;
                    }
                }
                if (!added)
                {
                    _danmakuList.Add(item);
                }
            }
        }
    }


    private static uint GetLayerId(DanmakuMode mode)
    {
        return mode switch
        {
            DanmakuMode.Bottom => DanmakuDefaultLayerDef.BottomLayerId,
            DanmakuMode.Top => DanmakuDefaultLayerDef.TopLayerId,
            DanmakuMode.ReverseRolling => DanmakuDefaultLayerDef.ReverseRollingLayerId,
            DanmakuMode.Advanced => DanmakuDefaultLayerDef.AdvancedLayerId,
            _ => DanmakuDefaultLayerDef.RollingLayerId,
        };
    }
}
