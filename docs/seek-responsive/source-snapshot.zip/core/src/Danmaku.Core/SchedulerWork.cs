
namespace Richasy.Danmaku;

// Internal selection protocol. Applied means managed selection committed, not
// native preparation, draw submission or presentation. OX/RX must own those fences.
internal enum SchedulerOutcome { Applied, Superseded, Closed, Faulted }

internal sealed class SchedulerWork
{
    internal readonly long Instance;
    internal readonly long AdmissionScene;
    internal long Scene;
    internal readonly uint Target;
    internal bool Seek;
    internal SchedulerSelection Selection { get; set; }
    internal readonly TaskCompletionSource<SchedulerOutcome> Completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
    internal SchedulerWork(long instance, long admissionScene, long scene, uint target, bool seek)
        => (Instance, AdmissionScene, Scene, Target, Seek) = (instance, admissionScene, scene, target, seek);
}

internal sealed class SchedulerSelection
{
    internal readonly SchedulerWork Work;
    internal readonly IReadOnlyList<DanmakuItem> Items;
    internal readonly int Cursor;
    internal SchedulerSelection(SchedulerWork work, List<DanmakuItem> items, int cursor)
        => (Work, Items, Cursor) = (work, items.AsReadOnly(), cursor);
}

internal readonly record struct SchedulerCurrent(long Instance, long Generation, long Scene,
    long Intent, bool Playing, bool Stopped, bool Pending, bool Closed, Exception? Error);
