using Microsoft.Extensions.Logging;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using System.Runtime.CompilerServices;

namespace Richasy.Danmaku;

/// <summary>Public facade. UI publishes; the resource owner performs all native work.</summary>
public sealed class DanmakuRenderer : IDisposable
{
    public const uint DefaultDanmakuLayerCount = DanmakuDefaultLayerDef.DefaultLayerCount;
    private sealed class Host
    {
        internal readonly CoreResourceHost Resources = new();
        internal Task Retirement = Task.CompletedTask;
    }
    private static readonly ConditionalWeakTable<Grid, Host> Hosts = new();
    private readonly CoreResourceOwner _owner;
    private readonly CoreExecutionBridge _bridge;
    private readonly DanmakuScheduler _scheduler;
    private readonly Grid _root;
    private readonly SwapChainPanel _panel;
    private bool _isDisposed;
    private bool _debugMode;
    private long _dirty, _appliedDirty;
    private Task<CoreResourceOutcome> _lastOperation = Task.FromResult(CoreResourceOutcome.Superseded);
    private Task _frame = Task.CompletedTask;
    private CoreSurfaceSize _publishedSize;

    public bool DebugMode
    {
        get => _debugMode;
        set { _debugMode = value; Track(_bridge.SetDebugAsync(value)); }
    }

    public DanmakuRenderer(Grid rootGrid, ILogger<DanmakuRenderer> logger = default, DanmakuConfiguration initialConfig = null)
    {
        ArgumentNullException.ThrowIfNull(rootGrid);
        for (int i = rootGrid.Children.Count - 1; i >= 0; i--)
        {
            if (rootGrid.Children[i] is not SwapChainPanel)
                rootGrid.Children.RemoveAt(i);
        }
        if (rootGrid.XamlRoot is null)
            throw new InvalidOperationException("rootGrid.XamlRoot is null - make sure the Grid is attached to the visual tree");
        _root = rootGrid;
        _panel = new SwapChainPanel { HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch };
        Logger.SetLogger(logger);
        var host = Hosts.GetValue(rootGrid, _ => new Host());
        lock (host)
        {
            _owner = new CoreResourceOwner(host.Resources, new CorePanelBinding(_panel), () => new CoreRenderSurface(), host.Retirement);
            _bridge = new CoreExecutionBridge(_owner);
            _scheduler = _bridge.Scheduler;
            host.Retirement = Task.WhenAll(_owner.Retirement, _bridge.SchedulerCompletion);
        }
        rootGrid.Children.Add(_panel);
        _panel.SizeChanged += SizeChanged;
        _panel.CompositionScaleChanged += ScaleChanged;
        CompositionTarget.Rendering += Rendering;
        Resize();
        Track(_bridge.ConfigureAsync(initialConfig));
    }
    private void SizeChanged(object sender, SizeChangedEventArgs args) => Resize();
    private void ScaleChanged(SwapChainPanel sender, object args) => Resize();
    private void Resize()
    {
        if (_isDisposed) return;
        var size = new CoreSurfaceSize((float)_panel.ActualWidth, (float)_panel.ActualHeight,
            (float)(_panel.XamlRoot?.RasterizationScale ?? 1));
        // XAML may report size and scale separately with the same final values.
        // Publishing that duplicate would retire a valid initial resource epoch.
        if (size == _publishedSize) return;
        _publishedSize = size;
        _owner.Resize(size.Width, size.Height, size.Scale);
        Interlocked.Increment(ref _dirty);
    }
    private void Track(Task<CoreResourceOutcome> operation)
    {
        var version = Interlocked.Increment(ref _dirty);
        _lastOperation = operation;
        _ = ObserveAsync(operation, version);
    }
    private async Task ObserveAsync(Task<CoreResourceOutcome> operation, long version)
    {
        try
        {
            var result = await operation.ConfigureAwait(false);
            // A stale receipt never acknowledges a later call's dirty state.
            if (result == CoreResourceOutcome.Applied && Interlocked.Read(ref _dirty) == version)
                Interlocked.Exchange(ref _appliedDirty, version);
        }
        catch (Exception error) { _owner.ReportUnconfirmed(error); }
    }
    private void Rendering(object? sender, object args)
    {
        if (_isDisposed || !_frame.IsCompleted || _owner.Error != null) return;
        var state = _scheduler.ReadCurrent();
        if (state.Closed || state.Error != null) return;
        if (!state.Playing && Interlocked.Read(ref _appliedDirty) == Interlocked.Read(ref _dirty)) return;
        var version = Interlocked.Read(ref _dirty);
        _frame = ObserveAsync(_bridge.FrameAsync(), version);
    }
    public void UpdateConfiguration(DanmakuConfiguration config) => Track(_bridge.ConfigureAsync(config));
    public void SetDanmakuEnabledType(bool? isRollingEnabled, bool? isTopEnabled, bool? isBottomEnabled)
        => _scheduler.SetDanmakuEnabledType(isRollingEnabled, isTopEnabled, isBottomEnabled);
    public void UpdateTime(uint currentMs) => Track(_bridge.UpdateTimeAsync(currentMs));
    public void Pause() => Track(_bridge.PauseAsync());
    public void Resume() => Track(_bridge.ResumeAsync());
    public void Stop() => Track(_bridge.StopAsync());
    public void Restart() { Resume(); Seek(0); }
    public void Seek(uint targetMs) => Track(_bridge.SeekAsync(targetMs));
    public void SetLayerRenderState(uint layerId, bool render) => Track(_bridge.SetLayerAsync(layerId, render));
    public void Clear() => Track(_bridge.ClearAsync());
    public void AddRealtimeDanmaku(DanmakuItem item, bool insertToList, uint? layerId = null)
        => Track(_bridge.AddRealtimeAsync(item, insertToList));
    public List<DanmakuItem> GetDanmakuList() => _scheduler?.GetDanmakuList() ?? new List<DanmakuItem>();
    public void SetDanmakuList(List<DanmakuItem> danmakuList)
    {
        var items = danmakuList.OrderBy(item => item.StartMs).ToList();
        Track(_bridge.SetListAsync(items));
    }
    public void AddDanmakuList(List<DanmakuItem> danmakuList) => _scheduler?.AddDanmakuList(danmakuList);
    public void Dispose()
    {
        if (_isDisposed) return;
        _isDisposed = true;
        CompositionTarget.Rendering -= Rendering;
        _panel.SizeChanged -= SizeChanged;
        _panel.CompositionScaleChanged -= ScaleChanged;
        _bridge.Dispose();
        _root.Children.Remove(_panel);
    }
}
