namespace Richasy.Danmaku;

// OX's surface owns the existing render algorithm and all of its caches/pools.
// Only stamped ExecuteAsync/SubmitAsync work may reach this surface.
internal sealed class CoreRenderSurface : ICoreOwnedSurface, ICoreSceneSurface, ICoreExecutionSurface
{
    private readonly int ownerThread = Environment.CurrentManagedThreadId;
    private readonly CoreNativeSurface native = new();
    private DirectXResourceManager? resources;
    private DanmakuDirectXRender? renderer;
    private bool disposed;
    private TimeSpan total;
    private TimeSpan elapsed;

    private void Verify()
    {
        if (ownerThread != Environment.CurrentManagedThreadId)
            throw new InvalidOperationException("Render surface accessed outside OX owner");
        ObjectDisposedException.ThrowIf(disposed, this);
    }
    public nint Pointer { get { Verify(); return native.Pointer; } }
    public void Initialize(CoreSurfaceSize size)
    {
        Verify(); native.Initialize(size);
        resources = new DirectXResourceManager(native.RenderContext, size);
        renderer = new DanmakuDirectXRender(resources, size);
    }
    public void Add(uint layer, DanmakuItem item) { Verify(); renderer!.RenderDanmakuItem(layer, item); }
    public void AddCaptured(uint layer, DanmakuItem preparation, DanmakuItem live)
    { Verify(); renderer!.PrepareDanmakuItem(layer, preparation, live, preparation.BaseFontSize); }
    public void SetPlayback(bool playing) { Verify(); renderer!.SetPlaybackOwned(playing); }
    public void Configure(DanmakuConfiguration config) { Verify(); renderer!.UpdateConfiguration(config); }
    internal void SetDebug(bool value) { Verify(); renderer!.DebugMode = value; }
    internal void SetLayer(uint layer, bool value) { Verify(); renderer!.SetLayerRenderState(layer, value); }
    internal void Clear() { Verify(); renderer!.Clear(); }
    public void SetTime(TimeSpan step, TimeSpan now) { Verify(); elapsed = step; total = now; }
    public void BeginRebuild(uint target, TimeSpan total) { Verify(); renderer!.BeginRebuildOwned(target, total); }
    public void AdvanceRebuild(TimeSpan step, TimeSpan now) { Verify(); renderer!.AdvanceRebuildOwned(step, now); }
    public void EndRebuild() { Verify(); renderer!.EndRebuildOwned(); }
    public void ChangeScene(long scene) { Verify(); renderer!.Clear(); elapsed = total = TimeSpan.Zero; }
    public void Resize(CoreSurfaceSize size)
    {
        Verify(); renderer!.Clear(); native.Resize(size); renderer.ResizeOwned(size);
    }
    public void Prepare()
    {
        Verify();
        using var borrow = resources!.ObjectPool.Borrow();
        using var session = native.BeginSession();
        renderer!.DrawOwned(elapsed, total);
    }
    public void Present() { Verify(); native.Present(); }
    public void AcquireLease() { Verify(); native.AcquireLease(); }
    public void ReleaseLease() { Verify(); native.ReleaseLease(); }
    public void Dispose()
    {
        if (disposed) return;
        Verify();
        // On any exception OX retains this entire graph and never retries disposal.
        renderer?.Dispose();
        resources?.Dispose();
        native.Dispose();
        renderer = null; resources = null; disposed = true;
    }
}
