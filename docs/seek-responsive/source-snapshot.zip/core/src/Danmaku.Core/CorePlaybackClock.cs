namespace Richasy.Danmaku;

// Only the OX worker advances this clock. Controls reset the sampling baseline;
// paused wall time is never added to the active total or the first resume step.
internal sealed class CorePlaybackClock
{
    private readonly TimeProvider time;
    private long sample;
    private long scene = -1, intent = -1;
    private bool playing;
    private TimeSpan total;
    internal CorePlaybackClock(TimeProvider? time = null) => this.time = time ?? TimeProvider.System;
    internal (TimeSpan Step, TimeSpan Total) Frame(SchedulerCurrent state)
    {
        long now = time.GetTimestamp();
        if (scene != state.Scene) { scene = state.Scene; total = TimeSpan.Zero; intent = -1; }
        TimeSpan step = playing && state.Playing && !state.Stopped && intent == state.Intent
            ? time.GetElapsedTime(sample, now) : TimeSpan.Zero;
        if (step < TimeSpan.Zero) step = TimeSpan.Zero;
        sample = now; intent = state.Intent; playing = state.Playing && !state.Stopped;
        total += step;
        return (step, total);
    }
}
