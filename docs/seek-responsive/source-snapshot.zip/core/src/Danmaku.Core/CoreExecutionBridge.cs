namespace Richasy.Danmaku;

internal interface ICoreExecutionSurface
{
    void Add(uint layer, DanmakuItem item);
    void AddCaptured(uint layer, DanmakuItem preparation, DanmakuItem live);
    void Configure(DanmakuConfiguration config);
    void SetPlayback(bool playing);
    void SetTime(TimeSpan step, TimeSpan total);
    void BeginRebuild(uint target, TimeSpan total);
    void AdvanceRebuild(TimeSpan step, TimeSpan total);
    void EndRebuild();
}

// Core facade consumer. All native work
// passes through the existing OX worker and RX1 surface/borrow protocol.
internal sealed class CoreExecutionBridge : IDisposable
{
    private readonly CoreResourceOwner owner;
    private readonly DanmakuScheduler scheduler;
    private readonly CorePlaybackClock clock;
    private readonly object configurationGate = new();
    private DanmakuConfiguration configuration = DanmakuConfiguration.CreateDefault();
    private long configurationRevision;
    private bool debug;
    private readonly Dictionary<uint, bool> layers = new();
    private readonly AsyncLocal<RealtimeReceipt?> realtimeReceipt = new();
    private sealed class RealtimeReceipt
    {
        internal Task<CoreResourceOutcome> Completion = Task.FromResult(CoreResourceOutcome.Superseded);
    }
    internal Task<CoreResourceOutcome> SetDebugAsync(bool value)
    { long revision; lock (configurationGate) { debug = value; revision = ++configurationRevision; } return RenderAsync(null, null, requestedConfiguration: revision); }
    internal Task<CoreResourceOutcome> SetLayerAsync(uint layer, bool value)
    { long revision; lock (configurationGate) { layers[layer] = value; revision = ++configurationRevision; } return RenderAsync(null, null, requestedConfiguration: revision); }
    private readonly object selectionGate = new();
    private Task selectionTail = Task.CompletedTask;
    // Worker-only applied configuration: replaying a full configuration every
    // frame would call UpdateLength and erase occupied Y slots.
    private float? appliedAreaRatio;
    private long configuredEpoch = -1;
    // Owner-only target reconstruction. A newly stamped frame can rebuild an
    // unplayed seek after style/size changes; this is not retrying a started job.
    private SchedulerSelection? preparedTarget;
    private long targetConfiguration = -1;
    private long targetEpoch = -1;
    private void ApplyConfiguration(ICoreExecutionSurface surface, DanmakuConfiguration config, long epoch)
    {
        var update = config.Clone();
        if (configuredEpoch == epoch && appliedAreaRatio == config.RollingAreaRatio)
            update.RollingAreaRatio = null;
        surface.Configure(update);
        if (surface is CoreRenderSurface actual)
        {
            lock (configurationGate)
            {
                actual.SetDebug(debug);
                foreach (var layer in layers) actual.SetLayer(layer.Key, layer.Value);
            }
        }
        configuredEpoch = epoch; appliedAreaRatio = config.RollingAreaRatio;
    }
    internal DanmakuScheduler Scheduler => scheduler;
    internal Task SchedulerCompletion => scheduler.Completion;
    internal Task Retirement => owner.Retirement;
    internal CoreExecutionBridge(CoreResourceOwner owner, TimeProvider? time = null)
    {
        this.owner = owner;
        clock = new(time);
        scheduler = new DanmakuScheduler(_ => { });
        // At the original synchronous multicast position: flags and layer are
        // already set, insertion and later subscribers have not happened yet.
        scheduler.DanmakuRendered += CaptureRealtime;
    }
    private SchedulerCurrent PublishCurrent()
    {
        var state = scheduler.ReadCurrent();
        owner.PublishScene(state.Scene); owner.PublishIntent(state.Intent);
        if (state.Closed) owner.Close();
        if (state.Error != null) owner.ReportUnconfirmed(state.Error);
        return state;
    }
    internal Task<CoreResourceOutcome> FrameAsync() => RenderAsync(null, null);
    internal Task<CoreResourceOutcome> PauseAsync()
    {
        long requestedIntent;
        try { requestedIntent = scheduler.PauseTracked(); }
        catch { PublishCurrent(); throw; }
        return RenderAsync(null, null, requestedIntent); // Applied is after current work, zero-step draw and Present.
    }
    internal Task<CoreResourceOutcome> ResumeAsync()
    {
        long requestedIntent;
        try { requestedIntent = scheduler.ResumeTracked(); }
        catch { PublishCurrent(); throw; }
        return RenderAsync(null, null, requestedIntent);
    }
    internal Task<CoreResourceOutcome> StopAsync()
    {
        (long Scene, long Intent) request;
        try { request = scheduler.StopTracked(); }
        catch { PublishCurrent(); throw; }
        return RenderAsync(null, null, request.Intent, request.Scene);
    }
    internal Task<CoreResourceOutcome> SetListAsync(List<DanmakuItem> items)
    {
        long request;
        try { request = scheduler.SetTracked(items); }
        catch { PublishCurrent(); throw; }
        return RenderAsync(null, null, null, request);
    }
    internal Task<CoreResourceOutcome> ClearAsync()
    {
        long request;
        try { request = scheduler.ClearTracked(); }
        catch { PublishCurrent(); throw; }
        return RenderAsync(null, null, null, request);
    }
    internal Task<CoreResourceOutcome> SeekAsync(uint target) => SelectAsync(target, true);
    internal Task<CoreResourceOutcome> UpdateTimeAsync(uint target) => SelectAsync(target, false);
    private Task<CoreResourceOutcome> SelectAsync(uint target, bool seek)
    {
        // Preserve QX progress order across asynchronous completion continuations.
        // Control publication never waits for this chain or the native worker.
        lock (selectionGate)
        {
            var work = scheduler.Enqueue(target, seek);
            PublishCurrent();
            var result = DeliverSelectionAsync(selectionTail, work);
            selectionTail = result;
            return result;
        }
    }
    private async Task<CoreResourceOutcome> DeliverSelectionAsync(Task previous, SchedulerWork work)
    {
        await previous.ConfigureAwait(false);
        var outcome = await work.Completion.Task.ConfigureAwait(false);
        if (outcome != SchedulerOutcome.Applied) return Convert(outcome);
        return await RenderAsync(work.Selection, null).ConfigureAwait(false);
    }
    internal Task<CoreResourceOutcome> AddRealtimeAsync(DanmakuItem item, bool insertToList)
    {
        var previous = realtimeReceipt.Value;
        var receipt = new RealtimeReceipt();
        realtimeReceipt.Value = receipt;
        try
        {
            AddRealtime(item, insertToList);
            var state = scheduler.ReadCurrent();
            if (state.Closed) return Task.FromResult(CoreResourceOutcome.Closed);
            if (state.Error != null || owner.Error != null) return Task.FromResult(CoreResourceOutcome.Faulted);
            return receipt.Completion;
        }
        finally { realtimeReceipt.Value = previous; }
    }
    internal void AddRealtime(DanmakuItem item, bool insertToList)
    {
        try { scheduler.AddRealtimeDanmaku(item, insertToList); }
        finally { PublishCurrent(); }
    }
    private void CaptureRealtime(uint layer, DanmakuItem item)
    {
        var state = scheduler.ReadCurrent();
        // Capture even if the native target has not become ready; no later
        // dereference may substitute another invocation's preparation fields.
        var captured = item.Clone();
        if (captured.BaseFontSize <= 0) captured.BaseFontSize = DanmakuItem.DefaultBaseFontSize;
        if (state.Closed || state.Error != null || state.Stopped) return;
        DanmakuConfiguration preparationConfig;
        lock (configurationGate) preparationConfig = configuration.Clone();
        var operation = RenderAsync(null, new Realtime(state, layer, captured, item, preparationConfig));
        if (realtimeReceipt.Value is { } receipt) receipt.Completion = operation;
    }
    private sealed record Realtime(SchedulerCurrent State, uint Layer, DanmakuItem Preparation, DanmakuItem Live, DanmakuConfiguration Configuration);
    private static CoreResourceOutcome Convert(SchedulerOutcome outcome) => outcome switch
    {
        SchedulerOutcome.Closed => CoreResourceOutcome.Closed,
        SchedulerOutcome.Faulted => CoreResourceOutcome.Faulted,
        SchedulerOutcome.Applied => CoreResourceOutcome.Applied,
        _ => CoreResourceOutcome.Superseded,
    };
    private async Task<CoreResourceOutcome> RenderAsync(SchedulerSelection? selection, Realtime? realtime, long? requestedIntent = null, long? requestedScene = null, long? requestedConfiguration = null)
    {
        bool started = false;
        // Waiting for the initial native allocation does not consume a selection.
        // Subsequent epoch changes still use RX2's strict no-replay boundary.
        await owner.Ready.ConfigureAwait(false);
        while (true)
        {
            var state = PublishCurrent();
            var origin = realtime?.State ?? state;
            if (state.Closed) return CoreResourceOutcome.Closed;
            if (state.Error != null || owner.Error != null) return CoreResourceOutcome.Faulted;
            // A control receipt cannot borrow a newer control's successful frame.
            if (requestedIntent.HasValue && state.Intent != requestedIntent.Value) return CoreResourceOutcome.Superseded;
            if (requestedScene.HasValue && state.Scene != requestedScene.Value) return CoreResourceOutcome.Superseded;
            lock (configurationGate)
                if (requestedConfiguration.HasValue && requestedConfiguration.Value != configurationRevision)
                    return CoreResourceOutcome.Superseded;
            if (origin.Instance != state.Instance || origin.Generation != state.Generation || origin.Scene != state.Scene)
                return CoreResourceOutcome.Superseded;
            if (selection != null && scheduler.ValidateSelection(selection) is { } invalid) return Convert(invalid);
            var stamp = owner.Capture();
            if (stamp.Epoch == 0 || stamp.Scene != state.Scene) return CoreResourceOutcome.Superseded;
            DanmakuConfiguration config; long revision;
            lock (configurationGate)
            {
                // Bind the request and its snapshot in the same critical section.
                if (requestedConfiguration.HasValue && requestedConfiguration.Value != configurationRevision)
                    return CoreResourceOutcome.Superseded;
                config = configuration.Clone(); revision = configurationRevision;
            }
            CoreResourceOutcome? Current()
            {
                var current = scheduler.ReadCurrent();
                if (current.Closed) return CoreResourceOutcome.Closed;
                if (current.Error != null) return CoreResourceOutcome.Faulted;
                if (current.Instance != state.Instance || current.Generation != state.Generation
                    || current.Scene != state.Scene || current.Intent != state.Intent || current.Pending)
                    return CoreResourceOutcome.Superseded;
                lock (configurationGate) if (realtime == null && revision != configurationRevision) return CoreResourceOutcome.Superseded;
                return selection == null ? null : scheduler.ValidateSelection(selection) is { } rejected ? Convert(rejected) : null;
            }
            var result = await owner.RenderAsync(stamp, Current, surface =>
            {
                started = true;
                var render = (ICoreExecutionSurface)surface;
                ApplyConfiguration(render, config, stamp.Epoch); render.SetPlayback(state.Playing && !state.Stopped);
                var tick = clock.Frame(state);
                if (preparedTarget != null && (preparedTarget.Work.Scene != state.Scene
                    || tick.Total > TimeSpan.Zero || realtime != null
                    || (selection != null && !selection.Work.Seek))) preparedTarget = null;
                var target = selection;
                if (target == null && preparedTarget != null
                    && (targetConfiguration != revision || targetEpoch != stamp.Epoch)
                    && !scheduler.ValidateSelection(preparedTarget).HasValue) target = preparedTarget;
                if (!state.Stopped)
                {
                    if (target != null && target.Work.Seek)
                    {
                        preparedTarget = target;
                        targetConfiguration = revision;
                        targetEpoch = stamp.Epoch;
                        render.BeginRebuild(target.Work.Target, tick.Total);
                        try
                        {
                            foreach (var item in target.Items)
                            {
                                if (scheduler.ValidateSelection(target).HasValue) break;
                                render.Add(Layer(item.Mode), item);
                            }
                            render.AdvanceRebuild(TimeSpan.Zero, tick.Total);
                        }
                        finally { render.EndRebuild(); }
                    }
                    else if (selection != null)
                        foreach (var item in selection.Items)
                        {
                            if (scheduler.ValidateSelection(selection).HasValue) break;
                            render.Add(Layer(item.Mode), item);
                        }
                    if (realtime != null && !Current().HasValue)
                    {
                        ApplyConfiguration(render, realtime.Configuration, stamp.Epoch);
                        render.AddCaptured(realtime.Layer, realtime.Preparation, realtime.Live);
                        // Layout uses call-time style; movement/draw use current style.
                        ApplyConfiguration(render, config, stamp.Epoch);
                    }
                }
                render.SetTime(tick.Step, tick.Total);
            }).ConfigureAwait(false);
            // Retry only work that never entered native preparation, and only
            // for a newer intent/config in this same scene/resource epoch.
            // Once preparation started, replaying could duplicate native items.
            var latest = scheduler.ReadCurrent();
            if (result != CoreResourceOutcome.Superseded || started || owner.Capture().Epoch != stamp.Epoch
                || latest.Scene != state.Scene || latest.Generation != state.Generation
                || (latest.Intent == state.Intent && revision == configurationRevision)) return result;
        }
    }
    private static uint Layer(DanmakuMode mode) => mode switch
    {
        DanmakuMode.Top => DanmakuDefaultLayerDef.TopLayerId,
        DanmakuMode.Bottom => DanmakuDefaultLayerDef.BottomLayerId,
        DanmakuMode.ReverseRolling => DanmakuDefaultLayerDef.ReverseRollingLayerId,
        DanmakuMode.Advanced => DanmakuDefaultLayerDef.AdvancedLayerId,
        _ => DanmakuDefaultLayerDef.RollingLayerId,
    };
    internal Task<CoreResourceOutcome> ConfigureAsync(DanmakuConfiguration value)
    {
        if (value == null) return FrameAsync();
        var c = value.Clone();
        long revision;
        lock (configurationGate)
        {
            if (c.AutoControlDensity.HasValue) configuration.AutoControlDensity = c.AutoControlDensity;
            if (c.IsTextBold.HasValue) configuration.IsTextBold = c.IsTextBold;
            if (c.NoOverlapSubtitle.HasValue) configuration.NoOverlapSubtitle = c.NoOverlapSubtitle;
            if (c.EnableParallelUpdate.HasValue) configuration.EnableParallelUpdate = c.EnableParallelUpdate;
            if (c.RollingDensity.HasValue) configuration.RollingDensity = c.RollingDensity;
            if (c.FontSizeScale.HasValue) configuration.FontSizeScale = c.FontSizeScale;
            if (c.RollingAreaRatio is > 0 and <= 1) configuration.RollingAreaRatio = c.RollingAreaRatio;
            if (c.RollingSpeedBase.HasValue) configuration.RollingSpeedBase = c.RollingSpeedBase;
            if (c.TextOpacity is > 0 and <= 1) configuration.TextOpacity = c.TextOpacity;
            if (c.OutlineSize is >= 0) configuration.OutlineSize = c.OutlineSize;
            if (c.BorderColor.HasValue) configuration.BorderColor = c.BorderColor;
            if (!string.IsNullOrEmpty(c.FontFamilyName)) configuration.FontFamilyName = c.FontFamilyName;
            revision = ++configurationRevision;
        }
        return RenderAsync(null, null, requestedConfiguration: revision);
    }
    public void Dispose() { scheduler.Dispose(); owner.Close(); }
}

