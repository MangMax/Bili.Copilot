using System.Numerics;
using System.Runtime.InteropServices;
using Vortice.Direct2D1;
using Vortice.Direct3D;
using Vortice.Direct3D11;
using Vortice.DXGI;

namespace Richasy.Danmaku;

// OX-only native resources. No scheduler, public facade, text pool or playback algorithm.
internal sealed class CoreNativeSurface : ICoreOwnedSurface
{
    private readonly int ownerThread = Environment.CurrentManagedThreadId;
    private ID3D11Device? d3d;
    private ID3D11DeviceContext? immediate;
    private IDXGISwapChain1? swap;
    private ID2D1Factory1? factory;
    private ID2D1Device? device;
    private ID2D1DeviceContext? context;
    private ID2D1Bitmap1? target;
    private bool session, disposed;
    private nint lease;
    [DllImport("combase.dll")] private static extern int RoInitialize(uint kind);
    [DllImport("combase.dll")] private static extern void RoUninitialize();
    internal CoreNativeSurface() { Marshal.ThrowExceptionForHR(RoInitialize(1)); }
    public nint Pointer { get { Verify(); return swap!.NativePointer; } }

    private void Verify()
    {
        if (Environment.CurrentManagedThreadId != ownerThread) throw new InvalidOperationException("Native resource accessed outside its owner");
        ObjectDisposedException.ThrowIf(disposed, this);
    }
    public void Initialize(CoreSurfaceSize size)
    {
        CreateDevice(); CreateSwapChain(size); CreateDrawingContext(); CreateTarget(size);
    }
    internal void CreateDevice()
    {
        Verify();
        D3D11.D3D11CreateDevice(null, DriverType.Hardware, DeviceCreationFlags.BgraSupport,
            new[] { Vortice.Direct3D.FeatureLevel.Level_11_0 }, out d3d, out immediate).CheckError();
    }
    internal void CreateSwapChain(CoreSurfaceSize size)
    {
        Verify();
        using var dx = d3d!.QueryInterface<IDXGIDevice>();
        using var adapter = dx.GetAdapter();
        using var dxFactory = adapter.GetParent<IDXGIFactory2>();
        swap = dxFactory.CreateSwapChainForComposition(d3d, new SwapChainDescription1
        {
            Width = checked((uint)(size.Width * size.Scale)), Height = checked((uint)(size.Height * size.Scale)),
            Format = Format.B8G8R8A8_UNorm, BufferCount = 2, BufferUsage = Usage.RenderTargetOutput,
            SampleDescription = new SampleDescription(1, 0), Scaling = Scaling.Stretch,
            SwapEffect = SwapEffect.FlipSequential, AlphaMode = Vortice.DXGI.AlphaMode.Premultiplied,
        });
    }
    internal void CreateDrawingContext()
    {
        Verify();
        using var dx = d3d!.QueryInterface<IDXGIDevice>();
        factory = D2D1.D2D1CreateFactory<ID2D1Factory1>();
        device = factory.CreateDevice(dx);
        context = device.CreateDeviceContext(DeviceContextOptions.None);
    }
    internal void CreateTarget(CoreSurfaceSize size)
    {
        Verify();
        using var buffer = swap!.GetBuffer<IDXGISurface>(0);
        target = context!.CreateBitmapFromDxgiSurface(buffer, new BitmapProperties1(
            new Vortice.DCommon.PixelFormat(Format.B8G8R8A8_UNorm, Vortice.DCommon.AlphaMode.Premultiplied),
            96, 96, BitmapOptions.Target | BitmapOptions.CannotDraw));
        context.Target = target;
        // Renderer dimensions, font sizes and positions are already physical pixels.
        context.SetDpi(96, 96);
        using var swap2 = swap.QueryInterface<IDXGISwapChain2>();
        swap2.MatrixTransform = Matrix3x2.CreateScale(1 / size.Scale);
    }
    public void Resize(CoreSurfaceSize size)
    {
        Verify();
        if (session) throw new InvalidOperationException("Resize during session");
        context!.Target = null;
        target?.Dispose(); target = null;
        swap!.ResizeBuffers(2, checked((uint)(size.Width * size.Scale)), checked((uint)(size.Height * size.Scale)),
            Format.B8G8R8A8_UNorm, SwapChainFlags.None).CheckError();
        CreateTarget(size);
    }
    internal IDisposable BeginSession()
    {
        Verify(); if (session) throw new InvalidOperationException("Nested drawing session");
        context!.BeginDraw(); session = true; return new DrawingSession(this);
    }
    internal ID2D1DeviceContext DrawingContext { get { Verify(); if (!session) throw new InvalidOperationException("No drawing session"); return context!; } }
    internal ID2D1DeviceContext RenderContext { get { Verify(); return context!; } }
    public void Prepare() { using var draw = BeginSession(); context!.Clear(new Vortice.Mathematics.Color4(0, 0, 0, 0)); }
    public void Present() { Verify(); if (session) throw new InvalidOperationException("Present during session"); swap!.Present(1, PresentFlags.None).CheckError(); }
    public void AcquireLease() { Verify(); if (lease != 0) throw new InvalidOperationException("Duplicate lease"); lease = Pointer; Marshal.AddRef(lease); }
    public void ReleaseLease() { Verify(); if (lease == 0) throw new InvalidOperationException("Missing lease"); Marshal.Release(lease); lease = 0; }
    public void Dispose()
    {
        if (disposed) return; Verify();
        if (session || lease != 0) throw new InvalidOperationException("Resource still borrowed");
        if (context != null) context.Target = null;
        target?.Dispose(); target = null;
        context?.Dispose(); context = null;
        device?.Dispose(); device = null;
        factory?.Dispose(); factory = null;
        swap?.Dispose(); swap = null;
        immediate?.Dispose(); immediate = null;
        d3d?.Dispose(); d3d = null;
        disposed = true;
        RoUninitialize();
    }
    private sealed class DrawingSession(CoreNativeSurface surface) : IDisposable
    {
        private bool ended;
        public void Dispose()
        {
            if (ended) return; surface.Verify(); ended = true;
            try { surface.context!.EndDraw().CheckError(); } finally { surface.session = false; }
        }
    }
}
